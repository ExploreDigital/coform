# Conversational Form

**Turning web forms into conversations.** CoForm is concept to easily turn any form element on a web page into a conversational form interface. It features conversational replacement of all input elements, reusable variables from previous questions and complete customization and control over the styling.


## Quick Start

Include ConversationalForm in your page:

```html
<script type="text/javascript" src="https://cf-4053.kxcdn.com/conversational-form/0.9.70/conversational-form.min.js" crossorigin></script>
```

