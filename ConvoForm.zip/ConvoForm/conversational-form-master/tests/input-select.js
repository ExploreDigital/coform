describe('Validate tag attributes', function() {
	it('True', function() {
		expect(true).toBe(true);
	});
});